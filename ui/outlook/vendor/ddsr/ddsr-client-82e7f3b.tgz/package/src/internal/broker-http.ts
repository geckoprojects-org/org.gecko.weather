/********************************************************************
 * Copyright (c) 2026 Contributors to the Eclipse Foundation.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Data In Motion Consulting - initial implementation
 ********************************************************************/

import type { EObject } from '@emfts/core';
import type { ConsumerSession, Diagnostic, ServiceInterface, ServiceProvider, ServiceReference,
  ServiceImplementation,
} from '@ddsr/model';
import { DDSRFactory } from '@ddsr/model';
import { serializeToXmi, deserializeFromXmi } from '../xmi/xmi-support';
import { asRoots, eClassName, firstOfClass, toArray } from './emf-util';
import { clientOrigin, withOrigin, type ClientOrigin } from './client-origin';
import { NO_TRACER, type CallTracer } from '@ddsr/telemetry';
import { withTracing } from './broker-tracing';

export interface BrokerHttpOptions {
  /** Broker base URL, e.g. http://localhost:8887/ddsr/rest */
  brokerUrl: string;
  /** X-DDSR-Requestor value for catalog operations (audit). */
  requestor?: string;
  /**
   * Which system this is, for the X-DDSR-Origin header every call
   * carries (#132): a deployment name such as payments-prod-eu. The
   * other half of the origin is a per-process id and comes from the
   * runtime. Deliberately not a host name — name the system, not the
   * machine.
   */
  originLabel?: string;
  /** Overrides the per-process runtime id; for tests. */
  originRuntimeId?: string;
  fetchFn?: typeof fetch;
  /**
   * Whoever is watching calls, if anyone is (#146). Without one the
   * client is exactly what it was.
   */
  tracer?: CallTracer;
}

const REQUESTOR_HEADER = 'X-DDSR-Requestor';
const SOURCE = 'org.gecko.ddsr.client.ts';

/**
 * Direct HTTP proxies for the broker REST API — the TS mirror of the
 * Java client's CatalogHttpProxy / ImplementationsHttpProxy / lookup
 * transport. The broker API is infrastructure, not a discovered
 * service, so these calls do NOT go through the FlavorPlugin pipeline.
 *
 * Wire details this class owns:
 * - publish/withdraw bodies are multi-root XMI: the ServiceProvider
 *   plus its referenced ServiceInterface stubs as sibling roots, so
 *   positional cross-references resolve on the broker.
 * - withdraw is POST /implementations/withdraw with that same body
 *   (the body-carrying DELETE variant is deprecated, D14).
 * - Diagnostics are read from the body regardless of HTTP status; a
 *   missing/unparseable body yields a synthesized ERROR diagnostic
 *   with code = HTTP status.
 * - EMF omits default-valued attributes, so an OK diagnostic arrives
 *   without severity/code — absent means OK/0, never "unknown".
 */
export class BrokerHttp {
  private readonly base: string;
  private readonly requestor: string;
  private readonly origin: ClientOrigin;
  private readonly fetchFn: typeof fetch;

  constructor(options: BrokerHttpOptions) {
    this.base = options.brokerUrl.replace(/\/+$/, '');
    this.origin = clientOrigin(options.originLabel, options.originRuntimeId);
    // The fallback is this client's own origin, not "anonymous". A
    // caller that names a requestor on purpose still wins; one that
    // does not is no longer anonymous by accident.
    this.requestor = options.requestor ?? this.origin.token;
    // Wrapped once, here, rather than added at each of the ten call
    // sites: #132 asks for the origin on EVERY call, and this is the
    // only place where that is true by construction. A new request
    // cannot forget a wrapper; it can forget a header. Mirrors the Java
    // client, where the same job is done by a ClientRequestFilter on
    // the shared JAX-RS client.
    // Two wrappers, for one reason: the origin and the trace context
    // both have to be on EVERY call, and this is the only place where
    // that is true by construction.
    this.fetchFn = withTracing(
      withOrigin(options.fetchFn ?? globalThis.fetch.bind(globalThis), this.origin),
      options.tracer ?? NO_TRACER,
      this.base,
      this.origin.token);
  }

  /** The origin token this client stamps on every request. */
  get originToken(): string {
    return this.origin.token;
  }

  get brokerUrl(): string {
    return this.base;
  }

  /** POST /implementations — provider plus interface stubs as siblings. */
  async publishImplementation(provider: ServiceProvider, interfaceStubs: ServiceInterface[]): Promise<Diagnostic> {
    return this.sendImplementation('/implementations', provider, interfaceStubs);
  }

  /**
   * POST /implementations/withdraw — same body shape as publish. The
   * canonical withdraw is a POST, not the body-carrying DELETE (many
   * HTTP stacks refuse a DELETE entity; see DECISIONS_PARITY D14).
   */
  async withdrawImplementation(provider: ServiceProvider, interfaceStubs: ServiceInterface[]): Promise<Diagnostic> {
    return this.sendImplementation('/implementations/withdraw', provider, interfaceStubs);
  }

  /** PUT /implementations — in-place modification (#55), same body shape as publish. */
  async modifyImplementation(provider: ServiceProvider, interfaceStubs: ServiceInterface[]): Promise<Diagnostic> {
    return this.sendImplementation('/implementations', provider, interfaceStubs, 'PUT');
  }

  /** GET /references — returns all roots of the multi-root response. */
  async getReferences(
    interfaceName: string,
    filter?: string,
    flavors?: string,
    consumerId?: string,
    fingerprint?: string
  ): Promise<unknown[]> {
    const params = new URLSearchParams({ interface: interfaceName });
    if (filter) params.set('filter', filter);
    if (flavors) params.set('flavors', flavors);
    if (consumerId) params.set('consumerId', consumerId);
    if (fingerprint) params.set('fingerprint', fingerprint);
    const response = await this.fetchFn(`${this.base}/references?${params}`, {
      headers: { Accept: 'application/xml' },
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`lookup failed: ${response.status} — ${body.slice(0, 300)}`);
    }
    const text = await response.text();
    if (!text.trim()) return [];
    return asRoots(deserializeFromXmi(text));
  }

  /** POST /catalog with X-DDSR-Requestor. */
  async addCatalogEntry(serviceInterface: ServiceInterface, requestor?: string): Promise<Diagnostic> {
    const response = await this.fetchFn(`${this.base}/catalog`, {
      method: 'POST',
      headers: this.xmlHeaders(requestor),
      body: serializeToXmi(serviceInterface as unknown as EObject),
    });
    return this.readDiagnostic(response);
  }

  /**
   * PUT /catalog/{name}/deprecate — optional body with reason/replacedBy.
   * With the (name, sd1) catalog key the optional fingerprint addresses
   * one of several coexisting contracts; a bare name works only while
   * it is unambiguous.
   */
  async deprecateCatalogEntry(name: string, details?: ServiceInterface, requestor?: string,
      fingerprint?: string): Promise<Diagnostic> {
    const response = await this.fetchFn(
      `${this.base}/catalog/${encodeURIComponent(name)}/deprecate${fingerprintQuery(fingerprint)}`, {
      method: 'PUT',
      headers: this.xmlHeaders(requestor),
      body: details ? serializeToXmi(details as unknown as EObject) : undefined,
    });
    return this.readDiagnostic(response);
  }

  /** DELETE /catalog/{name} — optional fingerprint, see deprecateCatalogEntry. */
  async removeCatalogEntry(name: string, requestor?: string, fingerprint?: string): Promise<Diagnostic> {
    const response = await this.fetchFn(
      `${this.base}/catalog/${encodeURIComponent(name)}${fingerprintQuery(fingerprint)}`, {
      method: 'DELETE',
      headers: { Accept: 'application/xml', [REQUESTOR_HEADER]: requestor ?? this.requestor },
    });
    return this.readDiagnostic(response);
  }

  /**
   * GET /catalog/{name} — undefined on 404 (plain-text body, no
   * Diagnostic). Several coexisting contracts under one name answer 409
   * unless the fingerprint picks one.
   */
  async getCatalogEntry(name: string, fingerprint?: string): Promise<ServiceInterface | undefined> {
    const response = await this.fetchFn(
      `${this.base}/catalog/${encodeURIComponent(name)}${fingerprintQuery(fingerprint)}`, {
      headers: { Accept: 'application/xml' },
    });
    if (response.status === 404) return undefined;
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`catalog read failed: ${response.status} — ${body.slice(0, 300)}`);
    }
    const text = await response.text();
    if (!text.trim()) return undefined;
    return firstOfClass<ServiceInterface>(asRoots(deserializeFromXmi(text)), 'ServiceInterface');
  }

  /**
   * PUT /consumers/{id} — the idempotent full replace of the acquisition
   * stage (ACQUISITION.md §4): acquire = add an id and PUT, release =
   * remove and PUT, heartbeat = an unchanged PUT. The wire form follows
   * the publish convention: the acquisition list travels as sibling
   * ServiceReference id-stubs (the model's acquisitions reference is
   * transient and never serialized).
   */
  async putConsumerSession(
    consumerId: string,
    acquiredReferenceIds: string[],
    session?: ConsumerSession
  ): Promise<Diagnostic> {
    const factory = DDSRFactory.eINSTANCE;
    const body = session ?? factory.createConsumerSession();
    if (!body.consumerId) body.consumerId = consumerId;
    const roots: EObject[] = [body as unknown as EObject];
    for (const referenceId of acquiredReferenceIds) {
      const stub = factory.createServiceReference();
      stub.id = referenceId;
      roots.push(stub as unknown as EObject);
    }
    const response = await this.fetchFn(`${this.base}/consumers/${encodeURIComponent(consumerId)}`, {
      method: 'PUT',
      headers: this.xmlHeaders(),
      body: serializeToXmi(roots[0], ...roots.slice(1)),
    });
    return this.readDiagnostic(response);
  }

  /** DELETE /consumers/{id} — shutdown-notify, releases all leases at once. */
  /**
   * Provider liveness (#52): `PUT /references/{id}/heartbeat?intervalSeconds=N`,
   * no body. The broker retires the registration with PROVIDER_LOST after
   * two missed heartbeats; 404 (code 212) means it no longer holds the
   * registration and the provider has to publish again.
   */
  async heartbeat(referenceId: string, intervalSeconds: number): Promise<Diagnostic> {
    const params = new URLSearchParams({ intervalSeconds: String(intervalSeconds) });
    const response = await this.fetchFn(
      `${this.base}/references/${encodeURIComponent(referenceId)}/heartbeat?${params}`, {
        method: 'PUT',
        headers: { Accept: 'application/xml', [REQUESTOR_HEADER]: this.requestor },
      });
    return this.readDiagnostic(response);
  }

  async deleteConsumerSession(consumerId: string): Promise<Diagnostic> {
    const response = await this.fetchFn(`${this.base}/consumers/${encodeURIComponent(consumerId)}`, {
      method: 'DELETE',
      headers: { Accept: 'application/xml' },
    });
    return this.readDiagnostic(response);
  }

  /** GET /consumers/{id} — what does the broker believe about this consumer? */
  async getConsumerSession(
    consumerId: string
  ): Promise<{ session: ConsumerSession; acquiredReferenceIds: string[] } | undefined> {
    const response = await this.fetchFn(`${this.base}/consumers/${encodeURIComponent(consumerId)}`, {
      headers: { Accept: 'application/xml' },
    });
    if (response.status === 404) return undefined;
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`session read failed: ${response.status} — ${text.slice(0, 300)}`);
    }
    const text = await response.text();
    if (!text.trim()) return undefined;
    const roots = asRoots(deserializeFromXmi(text));
    const session = firstOfClass<ConsumerSession>(roots, 'ConsumerSession');
    if (!session) return undefined;
    const acquiredReferenceIds = roots
      .filter(r => eClassName(r) === 'ServiceReference')
      .map(r => (r as ServiceReference).id)
      .filter((id): id is string => !!id);
    return { session, acquiredReferenceIds };
  }

  private async sendImplementation(
    path: '/implementations' | '/implementations/withdraw',
    provider: ServiceProvider,
    interfaceStubs: ServiceInterface[],
    method: 'POST' | 'PUT' = 'POST'
  ): Promise<Diagnostic> {
    // A detached `replaces` stub (UPDATE_POLICY.md §2) travels as a sibling
    // root so the cross-reference is resolvable on the broker side.
    const replaces = toArray<ServiceImplementation>(provider.implementations)
      .map(impl => impl.replaces)
      .filter((r): r is ServiceImplementation => r !== undefined && r !== null);
    const body = serializeToXmi(
      provider as unknown as EObject,
      ...(interfaceStubs as unknown as EObject[]),
      ...(replaces as unknown as EObject[])
    );
    const response = await this.fetchFn(`${this.base}${path}`, {
      method,
      headers: this.xmlHeaders(),
      body,
    });
    return this.readDiagnostic(response);
  }

  private xmlHeaders(requestor?: string): Record<string, string> {
    return {
      'Content-Type': 'application/xml',
      Accept: 'application/xml',
      [REQUESTOR_HEADER]: requestor ?? this.requestor,
    };
  }

  /**
   * Read a Diagnostic from any response, mirroring the Java client's
   * CatalogHttpProxy.readDiagnostic: the entity is read regardless of
   * status (4xx-with-Diagnostic works); a missing or unparseable body
   * becomes a synthesized ERROR diagnostic with code = HTTP status.
   */
  private async readDiagnostic(response: Response): Promise<Diagnostic> {
    const text = await response.text().catch(() => '');
    if (text.trim()) {
      try {
        const diagnostic = firstOfClass<Diagnostic>(asRoots(deserializeFromXmi(text)), 'Diagnostic');
        if (diagnostic) return normalizeDiagnostic(diagnostic);
      } catch {
        // fall through to the synthesized diagnostic
      }
    }
    const synthesized = DDSRFactory.eINSTANCE.createDiagnostic();
    synthesized.severity = response.ok ? 'OK' : 'ERROR';
    synthesized.code = response.ok ? 0 : response.status;
    synthesized.message = text.trim() || `HTTP ${response.status}`;
    synthesized.source = SOURCE;
    return synthesized;
  }
}

/**
 * EMF omits attributes at their default value, so a success diagnostic
 * arrives as bare `<ddsr:Diagnostic source="…"/>`. Absent severity/code
 * mean OK/0 by the model's defaults.
 */
export function normalizeDiagnostic(diagnostic: Diagnostic): Diagnostic {
  if (!diagnostic.severity) diagnostic.severity = 'OK';
  // The emf.ts reader currently yields attribute values as strings, so
  // coerce numerics defensively (finding recorded in DECISIONS_PARITY).
  const code = diagnostic.code as unknown;
  if (code === undefined || code === null || code === '') {
    diagnostic.code = 0;
  } else if (typeof code !== 'number') {
    const parsed = Number(code);
    diagnostic.code = Number.isNaN(parsed) ? 0 : parsed;
  }
  return diagnostic;
}

/** True when the diagnostic blocks the operation (ERROR or CANCEL). */
export function isError(diagnostic: Diagnostic | undefined): boolean {
  const severity = diagnostic?.severity;
  return severity === 'ERROR' || severity === 'CANCEL';
}

/** Query-string fragment addressing one of several coexisting contracts. */
function fingerprintQuery(fingerprint: string | undefined): string {
  return fingerprint ? `?fingerprint=${encodeURIComponent(fingerprint)}` : '';
}
